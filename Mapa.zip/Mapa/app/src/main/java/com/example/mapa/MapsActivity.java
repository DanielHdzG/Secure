package com.example.mapa;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private GoogleMap.OnCameraIdleListener onCameraIdleListener;
    private TextView resutText;
    private DatabaseReference mDatabase;
    private ArrayList<Marker> tmpRealTimeMakers = new ArrayList<>();
    private ArrayList<Marker> realTimeMarkers = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        mDatabase = FirebaseDatabase.getInstance().getReference();

//configuracion del mapa


    }


    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
        ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED)
        {

        }
        mMap.setMyLocationEnabled(true);

        //programacion para mover el icono
       /*/ mMap.setOnMarkerDragListener(new GoogleMap.OnMarkerDragListener() {
            @Override
            public void onMarkerDragStart(Marker marker) {

            }

            @Override
            public void onMarkerDrag(Marker marker) {

            }

            @Override
            public void onMarkerDragEnd(Marker marker) {
                Geocoder gc = new Geocoder(MapsActivity.this);
                LatLng robo = new LatLng(22.1552416,-101.0105521);

                double lat = robo.latitude;
                double lng = robo.longitude;
                List<Address> list = null;
                try {
                    list = gc.getFromLocation(lat, lng, 1);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                Address add = list.get(0);
                marker.setTitle(add.getLocality());

            }
        });
/*/
        mDatabase.child("usuarios").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot snapshot: dataSnapshot.getChildren()){
                    MapsPojo mp = snapshot.getValue(MapsPojo.class);
                    Double latitud = mp.getLatitud();
                    Double longitud = mp.getLongitud();
                    //latitud y longitud de slp
                    LatLng SLP = new LatLng(22.1564549,-101.05558);
                    mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(SLP,13));
//agregar el icono de ubicacion para hacer la publicacion
                    LatLng lugar = new LatLng(latitud,longitud);
                    mMap.addMarker(new MarkerOptions().icon(BitmapDescriptorFactory.fromResource
                            (R.drawable.ubicacion)).anchor(0.0f,0.7f).position(lugar).draggable(true));

                    //ROBO A MANO ARMADA ICONO ARMA



                    LatLng robo = new LatLng(22.1552416,-101.0105521);
                    mMap.addMarker(new MarkerOptions().icon(BitmapDescriptorFactory.fromResource(R.drawable.pistola)).anchor(0.0f,0.1f).position(robo).title("Robo a mano armada").snippet("Atraco a la tienda el Gusanito "));
                    LatLng zonapeligrosa = new LatLng(22.1750793,-100.9889158);
                    mMap.addMarker(new MarkerOptions().icon(BitmapDescriptorFactory.fromResource(R.drawable.advertencia)).anchor(0.0f,0.1f).position(zonapeligrosa).title("Zona peligrosa").snippet("Evitar la zona en la noche ").draggable(true));
                   // mMap.addMarker(new MarkerOptions().icon(BitmapDescriptorFactory.fromResource
                            //(R.mipmap.ic_marcador)).anchor(0.7f,0.6f).position(robo));
   //segundo robo
                    LatLng robo2 = new LatLng(22.1552416,-101.0105520);
                    mMap.addMarker(new MarkerOptions().icon(BitmapDescriptorFactory.fromResource(R.drawable.pistola)).anchor(0.0f,0.1f).position(robo)
                            .title("Robo a mano armada").snippet("Asalto a estudiante ").draggable(true));
                    MarkerOptions markerOptions = new MarkerOptions();
                    markerOptions.position(new LatLng(latitud,longitud));

                    tmpRealTimeMakers.add(mMap.addMarker(markerOptions));//esto agrega todos los datos del marcador
                    //incluyendo el tipo de robo, lat y long


                }
               realTimeMarkers.addAll(tmpRealTimeMakers);//incluye los arreglos
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        final LatLng PERTH = new LatLng(-31.90, 115.86);
        Marker perth = mMap.addMarker(new MarkerOptions()
                .position(PERTH)
                .draggable(true));


    }

}
